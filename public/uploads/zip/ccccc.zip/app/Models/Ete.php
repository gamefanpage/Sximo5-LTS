<?php namespace App\Models;

use Illuminate\Auth\Authenticatable;
use Illuminate\Database\Eloquent\Model;

class ete extends Sximo  {
	
	protected $table = 'address';
	protected $primaryKey = 'id';

	public function __construct() {
		parent::__construct();
		
	}

	public static function querySelect(  ){
		
		return "  SELECT address.* FROM address  ";
	}	

	public static function queryWhere(  ){
		
		return "  WHERE address.id IS NOT NULL ";
	}
	
	public static function queryGroup(){
		return "  ";
	}
	

}
